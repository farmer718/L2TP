#!/bin/sh

. ../cgi-bin/common/ajax_common

CAS_AUTH_CONF="${PGETC}/web/cas_auth.conf"


url_encode()
{
	echo "$1" | ${URLENCODE} -e
}


xml_extract_value()
{
	local xml="$1"
	local tag="$2"

	echo "$xml" | sed -n "s/.*<${tag}>\([^<]*\)<\/${tag}>.*/\1/p" | head -1
}


validate_ticket()
{
	local ticket="$1"

	[ -z "${ticket}" ] && return 1

	len=`echo "${ticket}" | wc -c`
	if [ ${len} -lt 10 ] || [ ${len} -gt 200 ]; then
		return 1
	fi

	echo "${ticket}" | grep -E '^[a-zA-Z0-9\-]+$' > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		return 1
	fi

	return 0
}

if [ -z "${CGI_ticket}" ]; then
	retjson 1 "No Ticket"
fi

if ! validate_ticket "${CGI_ticket}"; then
	retjson 1 "Invalid Ticket Format"
fi

# ��������ļ�
if [ ! -f "${CAS_AUTH_CONF}" ]; then
	retjson 1 "CAS Config Not Found"
fi

. ${CAS_AUTH_CONF}

if [ "${cas_auth}" != "1" ]; then
	retjson 1 "CAS Auth Disabled"
fi

if [ -z "${cas_user_url}" ]; then
	retjson 1 "CAS User URL Not Configured"
fi

# ����CAS, ��ȡ�û���Ϣ
SERVICE="https://${HTTP_HOST}${SCRIPT_NAME}"
CAS_URL="${cas_user_url}?service=`url_encode "${SERVICE}"`&ticket=`url_encode "${CGI_ticket}"`"
XML_RESPONSE=`${CURL} -s -k -m 10 "${CAS_URL}" 2>/dev/null`

if [ $? -ne 0 ] || [ -z "${XML_RESPONSE}" ]; then
	retjson 1 "CAS Request Failed"
fi

# ����XML��ȡ�û���
USERNAME=`xml_extract_value "${XML_RESPONSE}" "cas:user"`

if [ -z "${USERNAME}" ]; then
	USERNAME=`xml_extract_value "${XML_RESPONSE}" "user"`
fi

if [ -z "${USERNAME}" ]; then
	retjson 1 "Invalid Ticket"
fi

export CGI_action="cas_login"
export CGI_cas_level="${cas_level}"
export CGI_pakey=`${FLOWEYE} cloud config getkey=1`
export CGI_username=`${FLOWEYE} iconv utf8togb2312 "${USERNAME}"`

/usr/ramdisk/admin/login/user.cgi
